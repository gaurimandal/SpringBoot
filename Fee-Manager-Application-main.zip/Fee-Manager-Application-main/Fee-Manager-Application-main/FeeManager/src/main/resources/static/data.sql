Insert into Student (student_Id, student_Number, student_name, student_father_name, student_mother_name, student_dob, student_address, student_doa, student_contact_number,student_status,student_added_on,student_updated_on) 
values ('20240001','20240001', 'Student one','student father name', 'student mother name', '2000-01-01', 'India', '2024-04-01', '1234567890','Y','2024-04-01','2024-04-01');
Insert into Student (student_Id, student_Number, student_name, student_father_name, student_mother_name, student_dob, student_address, student_doa, student_contact_number,student_status,student_added_on,student_updated_on) 
values ('20240002','20240002', 'Student Two','student father name', 'student mother name', '2000-01-01', 'India', '2024-04-01', '1234567890','Y','2024-04-01','2024-04-01');
Insert into Student (student_Id, student_Number, student_name, student_father_name, student_mother_name, student_dob, student_address, student_doa, student_contact_number,student_status,student_added_on,student_updated_on) 
values ('20240003','20240003', 'Student Three','student father name', 'student mother name', '2000-01-01', 'India', '2024-04-01', '1234567890','Y','2024-04-01','2024-04-01');
Insert into Student (student_Id, student_Number, student_name, student_father_name, student_mother_name, student_dob, student_address, student_doa, student_contact_number,student_status,student_added_on,student_updated_on) 
values ('20240004','20240004', 'Student one','student father name', 'student mother name', '2000-01-01', 'India', '2024-04-01', '1234567890','Y','2024-04-01','2024-04-01');
Insert into Student (student_Id, student_Number, student_name, student_father_name, student_mother_name, student_dob, student_address, student_doa, student_contact_number,student_status,student_added_on,student_updated_on) 
values ('20240005','20240005', 'Student Two','student father name', 'student mother name', '2000-01-01', 'India', '2024-04-01', '1234567890','Y','2024-04-01','2024-04-01');
Insert into Student (student_Id, student_Number, student_name, student_father_name, student_mother_name, student_dob, student_address, student_doa, student_contact_number,student_status,student_added_on,student_updated_on) 
values ('20240006','20240006', 'Student Three','student father name', 'student mother name', '2000-01-01', 'India', '2024-04-01', '1234567890','Y','2024-04-01','2024-04-01');

Insert into Standard (standard_Id, standard_name, standard_division, standard_status, standard_added_on, standard_updated_on) 
values ('SD-202400061','Standard-1', 'A','Y','2024-04-01','2024-04-01');
Insert into Standard (standard_Id, standard_name, standard_division, standard_status, standard_added_on, standard_updated_on) 
values ('SD-202400062','Standard-2', 'A','Y','2024-04-01','2024-04-01');
Insert into Standard (standard_Id, standard_name, standard_division, standard_status, standard_added_on, standard_updated_on) 
values ('SD-202400063','Standard-3', 'A','Y','2024-04-01','2024-04-01');
Insert into Standard (standard_Id, standard_name, standard_division, standard_status, standard_added_on, standard_updated_on) 
values ('SD-202400064','Standard-4', 'A','Y','2024-04-01','2024-04-01');
Insert into Standard (standard_Id, standard_name, standard_division, standard_status, standard_added_on, standard_updated_on) 
values ('SD-202400065','Standard-5', 'A','Y','2024-04-01','2024-04-01');


Insert into Fees_Paid (fees_Paid_Id, fees_id, acadmic_Year, standard_id, student_Id, fee_Received_By,fees_paid_on) 
values ('FP-202400061','FEE-34467561', '2024-25','SD-202400065','20240006','Admin','2024-04-01');
Insert into Fees_Paid (fees_Paid_Id, fees_id, acadmic_Year, standard_id, student_Id, fee_Received_By,fees_paid_on) 
values ('FP-202400062','FEE-34467562', '2024-25','SD-202400064','20240004','Admin','2024-04-01');
Insert into Fees_Paid (fees_Paid_Id, fees_id, acadmic_Year, standard_id, student_Id, fee_Received_By,fees_paid_on) 
values ('FP-202400063','FEE-34467563', '2024-25','SD-202400065','20240003','Admin','2024-04-01');
Insert into Fees_Paid (fees_Paid_Id, fees_id, acadmic_Year, standard_id, student_Id, fee_Received_By,fees_paid_on) 
values ('FP-202400064','FEE-34467564', '2024-25','SD-202400064','20240005','Admin','2024-04-01');
Insert into Fees_Paid (fees_Paid_Id, fees_id, acadmic_Year, standard_id, student_Id, fee_Received_By,fees_paid_on) 
values ('FP-202400065','FEE-34467565', '2024-25','SD-202400065','20240001','Admin','2024-04-01');
