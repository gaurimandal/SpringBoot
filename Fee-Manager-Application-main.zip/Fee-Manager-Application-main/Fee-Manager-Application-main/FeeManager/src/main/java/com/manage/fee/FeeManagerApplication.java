package com.manage.fee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeeManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeeManagerApplication.class, args);
	}

}
