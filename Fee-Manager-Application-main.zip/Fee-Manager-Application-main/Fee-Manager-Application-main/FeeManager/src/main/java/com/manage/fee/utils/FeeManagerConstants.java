package com.manage.fee.utils;

public interface FeeManagerConstants {

	String NO_STR = "N";
}
